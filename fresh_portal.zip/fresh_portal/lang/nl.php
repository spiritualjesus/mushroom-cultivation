<?php

/**
 * Dutch language file - version .1.2
 *
 */

$this->text['Add_Record'] = 'Toevoegen';
$this->text['Search'] = 'Zoek';
$this->text['Clear_search'] = 'Reset zoeken';

$this->text['Go_back'] = 'Terug';
$this->text['Save'] = 'Bewaren';
$this->text['saved'] = 'bewaard';
$this->text['Delete'] = 'Verwijder';
$this->text['deleted'] = 'verwijderd';
$this->text['Edit'] = 'Bewerken';

$this->text['Previous'] = 'Vorige';
$this->text['Next'] = 'Volgende';

$this->text['Nothing_found'] = 'Niets gevonden';

$this->text['Check_the_required_fields'] = 'Controleer de verplichte (gele) velden';
$this->text['Protect_this_directory_with'] = 'Bescherm deze folder met ';

?>
